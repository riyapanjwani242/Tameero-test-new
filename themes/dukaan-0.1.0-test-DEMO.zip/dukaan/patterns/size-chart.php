<?php
/**
 * Title: Size chart
 * Slug: purple/size-chart
 * Categories: woo-commerce, purple
 * Keywords: size chart, table
 * Description: A size chart table.
 * Block Types: core/table
 * Viewport width: 1440
 *
 * @package purple
 */

?>

<!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0"><!-- wp:paragraph  -->
<p><?php esc_html_e( 'These size charts are a guide to help you find the right size for you. As many pieces are designed in a unique way, we suggest you also refer to the specific garment lengths and measurements provided in the product descriptions.', 'purple' );?></p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes","style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<figure class="wp-block-table is-style-stripes" style="margin-top:var(--wp--preset--spacing--50)"><table><tbody><tr><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'Size', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'EU', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'UK', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'FR', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'IT', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'Chest', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'Waist', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'Arm length', 'purple' );?></td><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'Low hip', 'purple' );?></td></tr><tr><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'XS', 'purple' );?></td><td class="has-text-align-center" data-align="center">32</td><td class="has-text-align-center" data-align="center">4</td><td class="has-text-align-center" data-align="center">34</td><td class="has-text-align-center" data-align="center">38</td><td class="has-text-align-center" data-align="center">76</td><td class="has-text-align-center" data-align="center">60</td><td class="has-text-align-center" data-align="center">59.7</td><td class="has-text-align-center" data-align="center">75</td></tr><tr><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'S', 'purple' );?></td><td class="has-text-align-center" data-align="center">34</td><td class="has-text-align-center" data-align="center">6</td><td class="has-text-align-center" data-align="center">36</td><td class="has-text-align-center" data-align="center">40</td><td class="has-text-align-center" data-align="center">80</td><td class="has-text-align-center" data-align="center">64</td><td class="has-text-align-center" data-align="center">59.6</td><td class="has-text-align-center" data-align="center">79</td></tr><tr><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'M', 'purple' );?></td><td class="has-text-align-center" data-align="center">36</td><td class="has-text-align-center" data-align="center">8</td><td class="has-text-align-center" data-align="center">38</td><td class="has-text-align-center" data-align="center">42</td><td class="has-text-align-center" data-align="center">84</td><td class="has-text-align-center" data-align="center">68</td><td class="has-text-align-center" data-align="center">59.8</td><td class="has-text-align-center" data-align="center">83</td></tr><tr><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'L', 'purple' );?></td><td class="has-text-align-center" data-align="center">38</td><td class="has-text-align-center" data-align="center">10</td><td class="has-text-align-center" data-align="center">40</td><td class="has-text-align-center" data-align="center">44</td><td class="has-text-align-center" data-align="center">88</td><td class="has-text-align-center" data-align="center">72</td><td class="has-text-align-center" data-align="center">60.0</td><td class="has-text-align-center" data-align="center">87</td></tr><tr><td class="has-text-align-center" data-align="center"><?php esc_html_e( 'XL', 'purple' );?></td><td class="has-text-align-center" data-align="center">42</td><td class="has-text-align-center" data-align="center">12</td><td class="has-text-align-center" data-align="center">42</td><td class="has-text-align-center" data-align="center">46</td><td class="has-text-align-center" data-align="center">92</td><td class="has-text-align-center" data-align="center">76</td><td class="has-text-align-center" data-align="center">60.2</td><td class="has-text-align-center" data-align="center">91</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'How to measure', 'purple' );?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Chest: Measure around the fullest part of your chest, keeping the tape measure horizontal.', 'purple' );?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Waist: Measure around your natural waistline, at the narrowest point.', 'purple' );?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Arm length: Measure from shoulder point to just below the wrist.', 'purple' );?>   </p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
